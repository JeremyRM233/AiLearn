<?php
  header("Location: PHP/fPage.php");
  exit;
 ?>
